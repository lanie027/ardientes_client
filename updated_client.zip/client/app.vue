<template>
    <NuxtPage/>
</template>
