<template>
     <NuxtLayout name="default">
        <h1 class="font-bold text-3xl text-stone-950">Courses</h1>

        <div class="text-black-400  text-stone-950 grid-cols-2 ">
            <div class="font-bold my-4 text-stone-950">Enrolled</div>
                <h1 class="block font-medium hover:text-blue-500 mr-5 w-64 text-center">
                    <img class="aspect-square object-cover w-64 h-auto ml-2" src="../images/digitall.png" alt="">Data and Digital Communications-SY2324-2T
                </h1>
                <h1 class="block font-medium hover:text-blue-500 mr-5 w-64 text-center">
                    <img class="aspect-square object-cover w-64 h-auto ml-2" src="../images/courses2.png" alt="">Web Programming-SY2324-2T</h1>
            </div>
        
        <div class="text-black-400  text-stone-950 grid-cols-2 ">
            <div class="font-bold my-4 text-stone-950">
    
                <h1 class="block font-medium hover:text-blue-500 mr-5 w-64 text-center">
                    <img class="aspect-square object-cover w-64 h-auto ml-2" src="../images/digitall.png" alt="">Network Technology-SY2324-2T
                </h1>
                <h1 class="block font-medium hover:text-blue-500 mr-5 w-64 text-center">
                    <img class="aspect-square object-cover w-64 h-auto ml-2" src="../images/courses2.png" alt="">Computer Programming 1-SY2324-2T
                </h1>
            </div>
        </div>     
        <div class=" text-black-400  text-red-500">
            <div class="font-bold my-4">Completed</div>
        </div>
    </NuxtLayout>
</template>

<script>
</script>

<style scoped>
</style>