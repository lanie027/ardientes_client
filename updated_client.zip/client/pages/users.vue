<template>
    <NuxtLayout name="default">
        <h1 class="font-bold text-darkblue text-lg">My circle</h1>
        <div class="text-sm my-3">
            <span class="m-3 list-image-none list-inside"><img src="../images/pficon.png" alt="">Friends</span>
        </div>
        <div class="text-sm my-3">
            <span class="m-3 list-image-none list-inside"><img src="../images/photos2.png" alt="">My teachers</span>
        </div>
        <div class="text-sm my-3">
            <span class="m-3 list-image-none list-inside"><img src="../images/photo1.png" alt="" srcset="">My parents</span>
        </div>
    </NuxtLayout>
</template>

<script>
</script>

<style scoped>
</style>