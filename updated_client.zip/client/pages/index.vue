<template>
   <NuxtLayout name="default">
        <div class = "block border-l-4 border-indigo-500 bg-indigo-50 py-2 pl-3 pr-4 text-base font-medium text-black">
            <span class="m-3">Home</span >
            <span class="m-3">MindCheck</span >
            <span class="m-3">News</span >
        </div>
        <h1 class="text-black text-xl my-4">Welcome</h1>

        <center class="my-6"><iframe width="853" height="480" src="https://www.youtube.com/embed/c01gCquFhEk" title="Be Future-ready at STI College" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe></center>
        <center class="my-6"><iframe width="853" height="480" src="https://www.youtube.com/embed/tFoGrLQiN4A" title="What Inspires You?" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe></center>
        <center><iframe width="853" height="480" src="https://www.youtube.com/embed/WBjx7ZVsu2k" title="STI Hymn" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe></center>
    </NuxtLayout>

</template>

<script>
</script>

<style scoped>
</style>