<template>
    <NuxtLayout name="default">
        
        <div class="about-section my-3 font-normal text-lg">

            <div class="mb-20 text-black">
                <h1 class="font-extrabold text-3xl">About</h1>
            <div class="font-bold my-5 ">Vision</div>
                <p>To be the leader in innovative and relevant education that nurtures individuals to become competent and responsible members of society.</p>
        
            <div class="font-bold my-5">Mission</div>
                <p>We are an institution committed to provide knowledge through the development and delivery of superior learning systems.
                We are an institution committed to provide knowledge through the development and delivery of superior learning systems.
                We strive to provide <br> optimum value to all our stakeholders — our students, our faculty members, our employees, our partners, our shareholders, and our community.
                </p>
            </div>

            <div>

                <h1 class="my-3 font-bold text-lg">History</h1>
                <p class="text-black my-6">From its humble beginnings on August 21, 1983 as a computer training center with only two campuses, STI College now has campuses all over the Philippines and has diversified into ICT-enhanced programs in Information Technology, Business and Management, Tourism and Hospitality Management, Engineering, Arts and Sciences, Maritime, and Senior & Junior High Schools.</p>
            
            </div>
            <a href="/more">
                <button class="bg-gray-300 hover:bg-gray-400 text-black font-bold py-2 px-4 rounded inline-flex items-center">
                    <span>Know more</span>
                </button>
            </a>
        </div>
    </NuxtLayout>

</template>

<script>
</script>

<style scoped>
</style>