<template>
    <NuxtLayout>
        <div class="font-sans">
            <h1 class="text-3xl font-extrabold mb-4">Programs</h1>
            
            <div>
                <h2 class="font-bold text-base">College Programs</h2>
                <p class="font-sans my-4">Be life-ready with the necessary skills and knowledge to be an in-demand professional.</p>
                <div>
                    <h1 class="bg-blue-300 max-w-screen-sm font-bold">Information & Communications Technology</h1>
                    <h2 class="bg-blue-100 max-w-screen-sm">BS in Information Technology</h2>
                    <h2 class="bg-blue-100 max-w-screen-sm">BS in Computer Science</h2>
                    <h2 class="bg-blue-100 max-w-screen-sm">BS in Information Systems</h2>
                    <h2 class="bg-blue-100 max-w-screen-sm">2-yr. Associate in Computer Technology </h2>

                </div>
                <div class="my-4">
                    <h1 class="bg-blue-300 max-w-screen-sm font-bold">Tourism and Hospitality Management</h1>
                    <h2 class="bg-blue-100 max-w-screen-sm">BS in Hospitality Management (BSHM)</h2>
                    <h2 class="bg-blue-100 max-w-screen-sm">BS in Culinary Management (BSCM)</h2>
                    <h2 class="bg-blue-100 max-w-screen-sm">BS in Tourism Management (BSTM)</h2>
                    <h2 class="bg-blue-100 max-w-screen-sm">3-yr. Hotel and Restaurant Administration (HRA)</h2>
                    <h2 class="bg-blue-100 max-w-screen-sm">2-yr. Hospitality and Restaurant Services (HRS)</h2>
                </div>
            </div>
            <div>
                <div class="my-6">
                    <h1 class="font-bold text-base">Senior High School</h1>
                    <p class="font-sans my-4">Be college-ready with the knowledge, training, and preparation to pursue a degree, start a business, or gain employment.</p>
                    <h1 class="bg-blue-300 max-w-screen-sm font-bold">Academic Track</h1>
                    <h2 class="bg-blue-100 max-w-screen-sm">Science, Technology, Engineering, and Mathematics (STEM)</h2>
                    <h2 class="bg-blue-100 max-w-screen-sm">Humanities and Social Sciences (HUMSS)</h2>
                    <h2 class="bg-blue-100 max-w-screen-sm">General Academic Strand</h2>
                    <h2 class="bg-blue-100 max-w-screen-sm">Accountancy, Business, and Management (ABM)</h2>
                    <h2 class="bg-blue-100 max-w-screen-sm">Culinary Arts (CulArts)</h2>
                    <h2 class="bg-blue-100 max-w-screen-sm">Information Communications Technology (ICT)</h2>
                    <h2 class="bg-blue-100 max-w-screen-sm">IT in Mobile App and Web Development</h2>
                </div>
            </div>
        </div>
    </NuxtLayout>
</template>
<script></script>
<style></style>