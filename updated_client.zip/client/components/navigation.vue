<!-- <template>
    <NuxtLink to="/">Home</NuxtLink>
    <NuxtLink to="/about">About</NuxtLink>
    <NuxtLink to="/resources">Resources</NuxtLink>
    <NuxtLink to="/courses">Courses</NuxtLink>
    <NuxtLink to="/users">User</NuxtLink>
    
</template>

<script setup>
</script>

<style scoped>
</style> -->


